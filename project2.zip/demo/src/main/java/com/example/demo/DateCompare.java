package com.example.demo;

import java.util.*;

public class DateCompare implements Comparator {
    @Override
    public  int compare(Object o1, Object o2)
    {
        Product1 p1=(Product1) o1;
        Product1 p2=(Product1) o2;
        return p1.getLaunchDate().compareTo(p2.getLaunchDate());
    }
}

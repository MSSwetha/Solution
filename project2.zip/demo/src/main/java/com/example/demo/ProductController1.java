package com.example.demo;

import java.util.*;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductController1 {
    @RequestMapping( value="/sortProducts", method= RequestMethod.POST )
    public List<Product1> sortProducts(@RequestBody ProductList list)
    {
        List<Product1> pl=(List<Product1>) list.getList().stream().sorted(new DateCompare());
        pl=(List<Product1>) list.getList().stream().sorted(new IdCompare());
        Collections.reverse(pl);
        return pl;
    }


}

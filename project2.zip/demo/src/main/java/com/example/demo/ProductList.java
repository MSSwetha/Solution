package com.example.demo;
import java.util.*;

public class ProductList {
    private ArrayList<Product1> list=new ArrayList<>();
    public ProductList()
    {}
    public ProductList(ArrayList<Product1> list)
    {
        this.list=list;
    }

    public ArrayList<Product1> getList() {
        return list;
    }

    public void setList(ArrayList<Product1> list) {
        this.list = list;
    }
}

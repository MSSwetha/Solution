package com.example.demo;

import java.util.*;

public class IdCompare implements Comparator {
    @Override
    public int compare(Object o1,Object o2)
    {
        Product1 p1=(Product1) o1;
        Product1 p2=(Product1) o2;
        return p1.getProductId().compareTo(p2.getProductId());
    }

}

package com.example.demo;

import java.util.*;

public class ProductList {
    private ArrayList<Product> prod=new ArrayList<>();
    public ProductList()
    {}
    public  ProductList(ArrayList<Product> prod)
    {
        this.prod=prod;
    }

    public ArrayList<Product> getProd() {
        return prod;
    }

    public void productsAdd()
    {
        Product p1=new Product("Product1","2021-03-16T08:53:48.616Z",10.0);
        Product p2=new Product("Product2","2021-03-16T08:53:48.616Z",5.0);
        Product p3=new Product("Product3","2021-03-16T09:10:48.616Z",30.0);
        Product p4=new Product("Product4","2021-03-16T09:10:48.616Z",20.0);
        Collections.addAll(prod,p1,p2,p3);
    }


}

package com.example.demo;

import java.util.*;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
    @RequestMapping(value= "/updateSupply",method= RequestMethod.POST)
    public List<Product> updateSupply(@RequestBody ProductList prod)
    {

    }

}

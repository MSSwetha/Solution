package com.example.demo;

import java.util.*;

public class Product {
    private String productId;
    private String date;
    private Double qty;

    public Product(String productId,String date,Double qty)
    {
        this.productId=productId;
        this.date=date;
        this.qty=qty;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Double getQty() {
        return qty;
    }

    public void setQty(Double qty) {
        this.qty = qty;
    }
}

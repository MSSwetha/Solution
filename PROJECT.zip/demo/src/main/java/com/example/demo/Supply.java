package com.example.demo;

import java.util.*;

public class Supply {
    private String productId;
    private Date date;
    private Double qty;
    private String status;

    public Supply(String orderId, String productId, Double qty,String status,Date date)
    {
        this.productId=productId;
        this.qty=qty;
        this.status=status;
        this.date=date;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public Double getQty() {
        return qty;
    }

    public void setQty(Double qty) {
        this.qty = qty;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
